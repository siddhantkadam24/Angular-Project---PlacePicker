import { Component, inject, OnInit, Signal, signal } from '@angular/core';

import { Place } from '../place.model';
import { PlacesComponent } from '../places.component';
import { PlacesContainerComponent } from '../places-container/places-container.component';
import { PlacesService } from '../places.service';
import { ErrorHandlingComponent } from "../error-handling/error-handling.component";
import { ErrorserviceService } from '../errorservice.service';

@Component({
  selector: 'app-available-places',
  standalone: true,
  templateUrl: './available-places.component.html',
  styleUrl: './available-places.component.css',
  imports: [PlacesComponent, PlacesContainerComponent, ErrorHandlingComponent],
})
export class AvailablePlacesComponent implements OnInit{


  places = signal<Place[] | undefined>(undefined);
  serv = inject(PlacesService);
  err = inject(ErrorserviceService);
  dec = signal<boolean | undefined>(undefined);

  ngOnInit(): void {
    this.serv.loadAvailablePlaces().subscribe({
      next:(value)=>{ this.places.set(value)},
      error:()=> this.dec.set(this.err.setErrorReason())
    })
    
  }

  receiveBool(dec: boolean) {
    this.dec.set(dec);
    }

   
  
}

