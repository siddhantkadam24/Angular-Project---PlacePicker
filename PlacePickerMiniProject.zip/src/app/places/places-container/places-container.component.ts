import { Component, inject, input, OnInit, output, signal } from '@angular/core';
import { PlacesService } from '../places.service';
import { Place } from '../place.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-places-container',
  standalone: true,
  imports: [],
  templateUrl: './places-container.component.html',
  styleUrl: './places-container.component.css'
})
export class PlacesContainerComponent {
  title = input.required<string>();
  
}

