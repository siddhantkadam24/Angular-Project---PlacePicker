import { Component, inject, input, OnInit, output, signal } from '@angular/core';

import { PlacesContainerComponent } from '../places-container/places-container.component';
import { PlacesComponent } from '../places.component';
import { Place } from '../place.model';
import { PlacesService } from '../places.service';
import { tap } from 'rxjs';
import { ErrorHandlingComponent } from '../error-handling/error-handling.component';
import { ErrorserviceService } from '../errorservice.service';

@Component({
  selector: 'app-user-places',
  standalone: true,
  templateUrl: './user-places.component.html',
  styleUrl: './user-places.component.css',
  imports: [PlacesContainerComponent, PlacesComponent, ErrorHandlingComponent],
})
export class UserPlacesComponent implements OnInit{
  
  // Userplaces = signal<Place[] | undefined>(undefined);
  us = inject(PlacesService)
  places = this.us.AlrLoadUserPlaces;
  dec = signal<boolean | undefined>(undefined);
  err = inject(ErrorserviceService)
  ngOnInit(){
    this.us.loadUserPlaces().subscribe(
      {error:()=> this.dec.set(this.err.setErrorReason())}
    )
 }

  deleteUserPlace(place:Place)
  {
    return this.us.removeUserPlace(place).subscribe()
  }

  receiveBool(dec: boolean) {
    this.dec.set(dec);
    }
  
    
}
