import { Component, EventEmitter, input, Output, output } from '@angular/core';

@Component({
  selector: 'app-error-handling',
  standalone: true,
  imports: [],
  templateUrl: './error-handling.component.html',
  styleUrl: './error-handling.component.css'
})
export class ErrorHandlingComponent {

@Output() sendBool = new EventEmitter<boolean>()
doFalse() {
return this.sendBool.emit(false);
}

}
