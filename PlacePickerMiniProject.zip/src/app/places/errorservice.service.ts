import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ErrorserviceService {
  
  constructor() {}
 
  setErrorReason()
  { 
    
    return true;
  }
}
