import { inject, Injectable, signal } from '@angular/core';

import { Place } from './place.model';
import { HttpClient } from '@angular/common/http';
import { catchError, map, Observable, pipe, tap, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class PlacesService {
  private userPlaces = signal<Place[]>([]);

  AlrLoadUserPlaces = this.userPlaces.asReadonly();
  http = inject(HttpClient)
  link = "http://localhost:3000/";

  loadAvailablePlaces() {
    return this.http.get<{ places: Place[] }>(this.link + "places").pipe(map((value) => value.places),
      catchError(() => {return throwError(()=>new Error("Oh no, no available places not loading :( "))},))

  }

  loadUserPlaces() {
    return this.http.get<{ places: Place[] }>(this.link + "user-places").pipe(tap((resData) => this.userPlaces.set(resData.places)), catchError(() => throwError(()=>new Error("Oh no, user  not loading :("))))

  }

  addPlaceToUserPlaces(place: Place) {
    let prevUserPlaces = this.userPlaces();

    if (!prevUserPlaces.some((object) => object.id === place.id)) {
      this.userPlaces.set([...prevUserPlaces, place]);
    }
    return this.http.put<Place>(this.link + "user-places/", { placeId: place.id }).pipe(

      catchError(() => {
        return throwError(
          this.userPlaces.set(prevUserPlaces)
        )
      }))

  }

  removeUserPlace(place: Place) {
    let prevUserPlaces = this.userPlaces;

    if (this.userPlaces().filter((p) => p.id !== place.id)) {
      this.userPlaces.set(prevUserPlaces().filter((p) => p.id !== place.id));
    }

    return this.http.delete<Place>(this.link + "user-places/" + place.id).pipe(
      catchError(() => {
        return throwError(
          this.userPlaces.set(prevUserPlaces())
        )
      }
      ))

  }


}
